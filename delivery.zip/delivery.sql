-- Adminer 4.7.7 PostgreSQL dump

INSERT INTO "delivery" ("id", "name", "created_at", "updated_at") VALUES
(1,	'StorePickup',	'2020-09-17 21:15:04.316634+00',	'2020-09-17 21:32:29.580604+00'),
(2,	'DeliverHome',	'2020-09-17 21:15:15.618827+00',	'2020-09-17 21:32:40.008243+00');

-- 2020-10-02 03:00:03.980239+00
